var searchData=
[
  ['information_0',['Author and Course Information',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['instructions_1',['Compilation Instructions',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]]
];
