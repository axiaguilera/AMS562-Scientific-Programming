var class_point =
[
    [ "Point", "class_point.html#ad92f2337b839a94ce97dcdb439b4325a", null ],
    [ "Point", "class_point.html#a1fe848bc20a73dc40bea64d4fb7d6c34", null ],
    [ "distanceFromOrigin", "class_point.html#a9df84f46a69a99e4decd61b50f5d92f1", null ],
    [ "distanceTo", "class_point.html#a3f583375e03727ff8613a9daf892071c", null ],
    [ "getX", "class_point.html#a655794dd595a4821987664bf1d9010e8", null ],
    [ "getY", "class_point.html#aa323a12bec85e28ce6575dccec4f8b28", null ],
    [ "operator+", "class_point.html#a0ef3420ebb7ea96414d4f95ea0b7bc28", null ],
    [ "scale", "class_point.html#a35e9abce585ba9ab77f0735e84c4adec", null ],
    [ "setX", "class_point.html#adbc0b7182d2912771af51abadfb1ce13", null ],
    [ "setY", "class_point.html#a0027f933157b5bcfa9f959487e3ffeee", null ],
    [ "toString", "class_point.html#a1b06b4422f9c2a4a84e7dc921f47cfa8", null ],
    [ "translate", "class_point.html#a9a15d0d47f655640496f7a9cefcd1578", null ],
    [ "x", "class_point.html#ab99c56589bc8ad5fa5071387110a5bc7", null ],
    [ "y", "class_point.html#afa38be143ae800e6ad69ce8ed4df62d8", null ]
];