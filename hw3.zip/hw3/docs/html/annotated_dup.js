var annotated_dup =
[
    [ "Line", "class_line.html", "class_line" ],
    [ "Point", "class_point.html", "class_point" ],
    [ "Rectangle", "class_rectangle.html", "class_rectangle" ],
    [ "Square", "class_square.html", "class_square" ]
];