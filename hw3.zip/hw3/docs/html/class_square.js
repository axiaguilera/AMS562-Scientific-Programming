var class_square =
[
    [ "Square", "class_square.html#aaf88270454d19c52faa13c4f64464a24", null ],
    [ "area", "class_square.html#ae215569d46f2dedeb3d9f42af2494915", null ]
];