var class_rectangle =
[
    [ "Rectangle", "class_rectangle.html#a8d7477d3840a91a14f7320f6bb7ee653", null ],
    [ "area", "class_rectangle.html#a9fe4d5c0977a31dcf605cb149a504ae2", null ],
    [ "is_inside_rectangle", "class_rectangle.html#ab8a82fbe6a98cb2a92131e48f4c9f218", null ],
    [ "perimeter", "class_rectangle.html#a5b2cea341e37b2a37a8494679230c185", null ],
    [ "bottom_right", "class_rectangle.html#a16df1e2a2d442dc538389921e1656118", null ],
    [ "top_left", "class_rectangle.html#a5c37d1f5a8674cd438e59e0686be1976", null ]
];