var hierarchy =
[
    [ "Line", "class_line.html", null ],
    [ "Point", "class_point.html", null ],
    [ "Rectangle", "class_rectangle.html", [
      [ "Square", "class_square.html", null ]
    ] ]
];