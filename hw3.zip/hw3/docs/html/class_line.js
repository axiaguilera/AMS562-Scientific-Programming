var class_line =
[
    [ "Line", "class_line.html#ac796d6222b1d0fb20c3d08fbcb296700", null ],
    [ "length", "class_line.html#a908b142ba4a17102326274ffcd83d3b4", null ],
    [ "slope", "class_line.html#ae9da49040ea5ddc0e82ce53df9ca558d", null ],
    [ "y_intercept", "class_line.html#aa2a90c69d7971ce0364c57fa3251e8cb", null ],
    [ "point1", "class_line.html#ab6012c2f92fffab0ff212c0207507b42", null ],
    [ "point2", "class_line.html#a4e1e8778438e57bd69ad69f34d998908", null ]
];