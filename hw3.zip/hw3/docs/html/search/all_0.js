var searchData=
[
  ['and_20course_20information_0',['Author and Course Information',['../index.html#autotoc_md6',1,'']]],
  ['area_1',['area',['../class_rectangle.html#a9fe4d5c0977a31dcf605cb149a504ae2',1,'Rectangle::area()'],['../class_square.html#ae215569d46f2dedeb3d9f42af2494915',1,'Square::area()']]],
  ['author_20and_20course_20information_2',['Author and Course Information',['../index.html#autotoc_md6',1,'']]]
];
