var searchData=
[
  ['information_0',['Author and Course Information',['../index.html#autotoc_md6',1,'']]],
  ['instructions_1',['Compilation Instructions',['../index.html#autotoc_md4',1,'']]]
];
