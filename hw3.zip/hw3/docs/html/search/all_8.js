var searchData=
[
  ['operator_2b_0',['operator+',['../class_point.html#a0ef3420ebb7ea96414d4f95ea0b7bc28',1,'Point']]],
  ['overview_1',['Project Overview',['../index.html#autotoc_md1',1,'']]]
];
