var searchData=
[
  ['scale_0',['scale',['../class_point.html#a35e9abce585ba9ab77f0735e84c4adec',1,'Point']]],
  ['setx_1',['setX',['../class_point.html#adbc0b7182d2912771af51abadfb1ce13',1,'Point']]],
  ['sety_2',['setY',['../class_point.html#a0027f933157b5bcfa9f959487e3ffeee',1,'Point']]],
  ['slope_3',['slope',['../class_line.html#ae9da49040ea5ddc0e82ce53df9ca558d',1,'Line']]],
  ['square_4',['Square',['../class_square.html#aaf88270454d19c52faa13c4f64464a24',1,'Square']]]
];
