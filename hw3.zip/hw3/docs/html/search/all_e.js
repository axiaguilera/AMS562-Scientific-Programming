var searchData=
[
  ['y_0',['y',['../class_point.html#afa38be143ae800e6ad69ce8ed4df62d8',1,'Point']]],
  ['y_5fintercept_1',['y_intercept',['../class_line.html#aa2a90c69d7971ce0364c57fa3251e8cb',1,'Line']]]
];
