var searchData=
[
  ['tostring_0',['toString',['../class_point.html#a1b06b4422f9c2a4a84e7dc921f47cfa8',1,'Point']]],
  ['translate_1',['translate',['../class_point.html#a9a15d0d47f655640496f7a9cefcd1578',1,'Point']]]
];
