var searchData=
[
  ['getx_0',['getX',['../class_point.html#a655794dd595a4821987664bf1d9010e8',1,'Point']]],
  ['gety_1',['getY',['../class_point.html#aa323a12bec85e28ce6575dccec4f8b28',1,'Point']]]
];
