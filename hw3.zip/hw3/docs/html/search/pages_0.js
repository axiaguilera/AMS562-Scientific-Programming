var searchData=
[
  ['and_20course_20information_0',['Author and Course Information',['../index.html#autotoc_md6',1,'']]],
  ['author_20and_20course_20information_1',['Author and Course Information',['../index.html#autotoc_md6',1,'']]]
];
