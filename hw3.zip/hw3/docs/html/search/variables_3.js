var searchData=
[
  ['x_0',['x',['../class_point.html#ab99c56589bc8ad5fa5071387110a5bc7',1,'Point']]]
];
