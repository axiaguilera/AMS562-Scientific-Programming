var searchData=
[
  ['area_0',['area',['../class_rectangle.html#a9fe4d5c0977a31dcf605cb149a504ae2',1,'Rectangle::area()'],['../class_square.html#ae215569d46f2dedeb3d9f42af2494915',1,'Square::area()']]]
];
