var searchData=
[
  ['top_5fleft_0',['top_left',['../class_rectangle.html#a5c37d1f5a8674cd438e59e0686be1976',1,'Rectangle']]],
  ['tostring_1',['toString',['../class_point.html#a1b06b4422f9c2a4a84e7dc921f47cfa8',1,'Point']]],
  ['translate_2',['translate',['../class_point.html#a9a15d0d47f655640496f7a9cefcd1578',1,'Point']]]
];
