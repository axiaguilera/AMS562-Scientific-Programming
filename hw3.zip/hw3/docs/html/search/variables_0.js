var searchData=
[
  ['bottom_5fright_0',['bottom_right',['../class_rectangle.html#a16df1e2a2d442dc538389921e1656118',1,'Rectangle']]]
];
