var searchData=
[
  ['point1_0',['point1',['../class_line.html#ab6012c2f92fffab0ff212c0207507b42',1,'Line']]],
  ['point2_1',['point2',['../class_line.html#a4e1e8778438e57bd69ad69f34d998908',1,'Line']]]
];
